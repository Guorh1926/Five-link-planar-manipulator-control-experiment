function res=path(t)
global q0 T aa bb cc initx inity

% x0=a*sin(pi*0/10);
% y0=a*cos(pi*0/10);
% x=a*sin(pi*t/10);
% y=a*cos(pi*t/10);
% pos(:,:)=position(q0);
% res=[x;y]+pos(4,:)'-[x0;y0];
%lj
% x0=1+1/2*cos(0)+1/6*cos(4/3*0);
% y0=1+1/2*sin(0)-1/6*sin(4/3*0);
% % x=1+1/2*cos(t)+1/6*cos(4/3*t);
% % y=1+1/2*sin(t)-1/6*sin(4/3*t);
% x=1.8+1/2*cos(t)+1/6*cos(4/3*t);
% y=2.4+1/2*sin(t)-1/6*sin(4/3*t);
% pos(:,:)=position(q0);
% res=[x;y]+pos(5,:)'-[x0;y0];

% x0=1+1/2*cos(0)+1/6*cos(4/3*0);
% y0=1+1/2*sin(0)-1/6*sin(4/3*0);

% x=1.8+1/2*cos(t)+1/6*cos(4/3*t);
% y=2.5+1/2*sin(t)-1/6*sin(4/3*t);

% a=0.3;
% theta=t/3*2*pi;
% r=a*(2+3*cos(theta));
% x=r*cos(theta)+1.5;
% y=r*sin(theta)+2.8;
theta=2*pi*sin(0.5*pi*t/T)*sin(0.5*pi*t/T);
theta0=2*pi*sin(0.5*pi*0/T)*sin(0.5*pi*0/T);
%pos(:,:)=position(q0);

x=(cc*aa+aa*cos(bb*theta))*cos(theta);
y=(cc*aa+aa*cos(bb*theta))*sin(theta);
x0=(cc*aa+aa*cos(bb*theta0))*cos(theta0);
y0=(cc*aa+aa*cos(bb*theta0))*sin(theta0);
res=[x+initx-x0;y+inity-y0]+[-0.4;-0.1];
end
%pos(:,:)=position(q0);
%res=[x;y];


%ʧ��
% a=0.36;
% theta=t/3*2*pi;
% r=a*(1+2*cos(theta));
% % x=r*cos(theta)+1.5;
% % y=r*sin(theta)+2.8;
% x0=r*cos(0)+1.3;
% y0=r*sin(0)+2.5
% x=r*cos(theta)+1.3;
% y=r*sin(theta)+2.5
%  pos(:,:)=position(q0);
%  res=[x;y]+pos(4,:)'-[x0;y0];
% x0=a*sin(pi*0/10);
% y0=a*cos(pi*0/10);
% 
% x=a*sin(pi*t/10);
% y=a*cos(pi*t/10);
% 
% pos(:,:)=position(q0);
% res=[x;y]+pos(4,:)'-[x0;y0]+[0.2;-0.1];