function J=Jacob(q) %Jacobian matrix based on five-link planar robot manipulator

s5=sin(q(1)+q(2)+q(3)+q(4)+q(5));
s4=sin(q(1)+q(2)+q(3)+q(4));
s3=sin(q(1)+q(2)+q(3));
s2=sin(q(1)+q(2));
s1=sin(q(1));

c5=cos(q(1)+q(2)+q(3)+q(4)+q(5));
c4=cos(q(1)+q(2)+q(3)+q(4));
c3=cos(q(1)+q(2)+q(3));
c2=cos(q(1)+q(2));
c1=cos(q(1));


J=[-s1-s2-s3-s4-s5,-s2-s3-s4-s5,-s3-s4-s5,-s4-s5,-s5;...
  c1+c2+c3+c4+c5,c2+c3+c4+c5,c3+c4+c5,c4+c5,c5];