% function res=dotPath(t)
function dotxy=dotPath(t)
global q0 T aa bb cc
%   syms u real
%    xy=path(u);
%    x=xy(1);
%    y=xy(2);
%    dotx=diff(x);
%    doty=diff(y);
%    u=t;
%    dotxy=[eval(dotx);eval(doty)];
   
%     dotx=a*pi/10*cos(pi*t/10);
%     doty=-a*pi/10*sin(pi*t/10);
%lj
    
drdx=-(2*pi^2*cos((pi*t)/(2*T))*sin((pi*t)/(2*T))*sin(2*pi*sin((pi*t)/(2*T))^2)*(aa*cc + aa*cos(2*pi*bb*sin((pi*t)/(2*T))^2)))/T - (2*pi^2*aa*bb*sin(2*pi*bb*sin((pi*t)/(2*T))^2)*cos((pi*t)/(2*T))*sin((pi*t)/(2*T))*cos(2*pi*sin((pi*t)/(2*T))^2))/T;
drdy=(2*pi^2*cos((pi*t)/(2*T))*sin((pi*t)/(2*T))*cos(2*pi*sin((pi*t)/(2*T))^2)*(aa*cc + aa*cos(2*pi*bb*sin((pi*t)/(2*T))^2)))/T - (2*pi^2*aa*bb*sin(2*pi*bb*sin((pi*t)/(2*T))^2)*cos((pi*t)/(2*T))*sin((pi*t)/(2*T))*sin(2*pi*sin((pi*t)/(2*T))^2))/T;
% drdz=0;  

dotxy=[drdx;...
  drdy];
     

%ʧ��
% dotx=- (2*pi*sin((2*pi*t)/3)*((18*cos((2*pi*t)/3))/25 + 9/25))/3 - (12*pi*cos((2*pi*t)/3)*sin((2*pi*t)/3))/25;
% doty=(2*pi*cos((2*pi*t)/3)*((18*cos((2*pi*t)/3))/25 + 9/25))/3 - (12*pi*sin((2*pi*t)/3)^2)/25;
%     dotxy=[dotx;doty];
end