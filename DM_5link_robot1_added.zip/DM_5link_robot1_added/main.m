clc;
clear all;
close all;
format long;

global q0 T aa bb cc initx inity 

%%%%%%%%%%%%%%%%%%%flower path %����ΪT
aa=0.24; %����ͼ�δ�С
bb=6; %6 %����������  
cc=1.2; %4 %���������С�ͷ���
T=10;
tau=0.01;
%h=0.05; %test
h=0.1;
t=0:tau:T;
iter=length(t);
%theta(:,1)=[pi/5;-pi/5;pi/9;pi/4];
q0=[pi/6;-pi/4;pi/6;pi/3;pi/4];
% theta(:,1)=[pi/6;pi/4;pi/2];
%q0=theta(:,1);
theta1(:,1)=q0;
theta2(:,1)=q0;
theta3(:,1)=q0;
theta4(:,1)=q0;
gamma=h/tau;
%gamma=10;
I5=eye(5);
p=0.1;
%p=10;
[Ppx,Ppy]=position(theta2(:,1));
initx=Ppx(end);
inity=Ppy(end);

%gamma=1000;

% A=[0,0,0,1];
% b=0;

% A=[1,1,1,1];
% b=0;

 A=[0,1,0,0,0;1,1,1,1,1];
 b=[0;0];
 
%novel direct-discretization RNN algorithm
for i=1:length(t)
    [posix1(:,i),posiy1(:,i)]=position(theta1(:,i));
    r1(:,i)=[posix1(end);posiy1(end)];
    rd(:,i)=path(t(i));
    theta1(:,i+1)=pinv([Jacob(theta1(:,i));A/tau])*([tau*dotPath(t(i))+h*(rd(:,i)-r1(:,i));b])+theta1(:,i);
    err1(:,i)=norm(r1(:,i)-rd(:,i));
end

%Indirect-discretization gradient-based RNN algorithm
for i=1:length(t)
    [posix2(:,i),posiy2(:,i)]=position(theta2(:,i));
     r2(:,i)=[posix2(end);posiy2(end)];
     rd(:,i)=path(t(i));
    %tic;
    theta2(:,i+1)=tau*pinv([I5;A])*([gamma*Jacob(theta2(:,i))'*(rd(:,i)-r2(:,i));b])+theta2(:,i);
    err2(:,i)=norm(r2(:,i)-rd(:,i));
    %tic2(i)=toc;
end

%Indirect-discretization power-type RNN algorithm
for i=1:length(t)
    [posix3(:,i),posiy3(:,i)]=position(theta3(:,i));
     r3(:,i)=[posix3(end);posiy3(end)];
     rd(:,i)=path(t(i));
    %tic;
    theta3(:,i+1)=tau*pinv([Jacob(theta3(:,i));A])*([dotPath(t(i))+((i*tau)^p+p)*(rd(:,i)-r3(:,i));b])+theta3(:,i);
    err3(:,i)=norm(r3(:,i)-rd(:,i));
    %tic2(i)=toc;
end
%Indirect-discretization exponential-type RNN algorithm
for i=1:length(t)
    [posix4(:,i),posiy4(:,i)]=position(theta4(:,i));
     r4(:,i)=[posix4(end);posiy4(end)];
     rd(:,i)=path(t(i));
    %tic;
    theta4(:,i+1)=tau*pinv([Jacob(theta4(:,i));A])*([dotPath(t(i))+gamma*exp(i*tau)*(rd(:,i)-r4(:,i));b])+theta4(:,i);
    err4(:,i)=norm(r4(:,i)-rd(:,i));
    %tic2(i)=toc;
end


figure(1);plot(1:length(t)-1,theta2(1,1:length(t)-1),1:length(t)-1,theta2(2,1:length(t)-1),'--',...
    1:length(t)-1,theta2(3,1:length(t)-1),1:length(t)-1,theta2(4,1:length(t)-1),1:length(t)-1,theta2(5,1:length(t)-1),'-.','LineWidth',2);hold on;
legend('theta1','theta2','theta3','theta4','theta5');
figure(1);plot(1:length(t)-1,theta(1,1:length(t)-1),1:length(t)-1,theta(2,1:length(t)-1),'--',...
    1:length(t)-1,theta(3,1:length(t)-1),'-.',1:length(t)-1,theta(1,1:length(t)-1)+theta(2,1:length(t)-1)...
    +theta(3,1:length(t)-1),'LineWidth',2);hold on;
legend('theta1','theta2','theta3','theta1theta2theta3');


robot_trajectory=figure;
% axis([-4 1 0 3]);
% plot(thexy(1,:),thexy(2,:),'r',posix(end,:),posiy(end,:),'b--','LineWidth',2); hold on;
plot(rd(1,:),rd(2,:),'r:','LineWidth',2);hold on 
for i=1:floor(iter/60):length(t) %60 %80
    plot([posix2(1,i),posix2(2,i)],[posiy2(1,i),posiy2(2,i)],'k'); hold on;
    plot([posix2(2,i),posix2(3,i)],[posiy2(2,i),posiy2(3,i)],'m'); hold on;
    plot([posix2(3,i),posix2(4,i)],[posiy2(3,i),posiy2(4,i)],'b'); hold on;
    plot([posix2(4,i),posix2(5,i)],[posiy2(4,i),posiy2(5,i)],'r'); hold on;
    plot([posix2(5,i),posix2(6,i)],[posiy2(5,i),posiy2(6,i)],'c'); hold on;
pause(.1);
drawnow;
end
plot(posix2(6,:),posiy2(6,:),'b--','LineWidth',2); hold on;
pause(1);


figure(3);plot(rd(1,:),rd(2,:),'r:',posix2(6,:),posiy2(6,:),'b--','LineWidth',2);hold on;
legend('desiredPath','ActualTrajectory');

robot_trajectory1=figure;
% axis([-4 1 0 3]);
% plot(thexy(1,:),thexy(2,:),'r',posix(end,:),posiy(end,:),'b--','LineWidth',2); hold on;
plot(rd(1,:),rd(2,:),'r:','LineWidth',2); hold on;
for i=1:floor(iter/60):length(t) %60 %80
    plot([posix1(1,i),posix1(2,i)],[posiy1(1,i),posiy1(2,i)],'k'); hold on;
    plot([posix1(2,i),posix1(3,i)],[posiy1(2,i),posiy1(3,i)],'m'); hold on;
    plot([posix1(3,i),posix1(4,i)],[posiy1(3,i),posiy1(4,i)],'b'); hold on;
    plot([posix1(4,i),posix1(5,i)],[posiy1(4,i),posiy1(5,i)],'r'); hold on;
    plot([posix1(5,i),posix1(6,i)],[posiy1(5,i),posiy1(6,i)],'c'); hold on;
pause(.1);
drawnow;
end
plot(posix1(6,:),posiy1(6,:),'b--','LineWidth',2); hold on;
pause(1);


figure(4);plot(posix1(6,:),posiy1(6,:),'b',rd(1,:),rd(2,:),'--r','LineWidth',2);hold on;
legend('ActualTrajectory','desiredPath');
figure(5);semilogy(1:iter,err1,1:iter,err2, '-.','LineWidth',2);
hold on;
figure(6);semilogy(1:iter,err1,1:iter,err3, 1:iter,err4,'LineWidth',2);
hold on;
figure(7);semilogy(1:iter,err1,'b-',1:iter,err2,'m--',1:iter,err3, 'r-.','LineWidth',2);
hold on; 
figure(8);plot(1:length(t)-1,theta1(1,1:length(t)-1)+theta1(2,1:length(t)-1)+theta1(3,1:length(t)-1)...
    +theta1(4,1:length(t)-1)+theta1(5,1:length(t)-1),'LineWidth',2);hold on;
legend('sum');


 