function [x,y]=position(q)%calculate positions of each link based on joint-angle vector

s5=sin(q(1)+q(2)+q(3)+q(4)+q(5));
s4=sin(q(1)+q(2)+q(3)+q(4));
s3=sin(q(1)+q(2)+q(3));
s2=sin(q(1)+q(2));
s1=sin(q(1));

c5=cos(q(1)+q(2)+q(3)+q(4)+q(5));
c4=cos(q(1)+q(2)+q(3)+q(4));
c3=cos(q(1)+q(2)+q(3));
c2=cos(q(1)+q(2));
c1=cos(q(1));

x=[0;c1;c1+c2;c1+c2+c3;c1+c2+c3+c4;c1+c2+c3+c4+c5];
y=[0;s1;s1+s2;s1+s2+s3;s1+s2+s3+s4;s1+s2+s3+s4+s5];
end

%res=[x,y];
% res=[x(4);y(4)];